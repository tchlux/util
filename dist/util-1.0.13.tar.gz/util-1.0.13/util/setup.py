#!python 

# Any python code that should be executed (as if __main__) should go
# here to prepare the modeul for function on a new computer.
