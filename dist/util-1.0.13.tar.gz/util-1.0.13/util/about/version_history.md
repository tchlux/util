| 1.0.0<br>September 2019 | Cleaning up, testing for import on other machines. |
| 1.0.1<br>September 2019 | Cleaning up, testing for import on other machines. |
| 1.0.2<br>September 2019 | Fixing manifest. |
| 1.0.3<br>September 2019 | Overwrote bad old tag on git. |
| 1.0.4<br>September 2019 | Trying new setup.py |
| 1.0.6<br>September 2019 | pip 19 adhering requirements |
| 1.0.7<br>September 2019 | Using pip directly to install. |
| 1.0.8<br>September 2019 | Using pip directly to install. |
| 1.0.9<br>September 2019 | Using pip directly to install. |
| 1.0.10<br>September 2019 | Removed problematic requirements. |
| 1.0.11<br>September 2019 | Bug fixes and rebuilds, still failing to install. |
| 1.0.12<br>September 2019 | Bug fixes and rebuilds, still failing to install. |
| 1.0.13<br>September 2019 | Bug fixes and rebuilds, still failing to install. |
